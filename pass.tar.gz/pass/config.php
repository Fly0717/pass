<?php
    $servername = "localhost";  // 数据库连接名，为数据库地址
    $dbusername = "user";  // 数据库用户名
    $dbpassword = "password";  // 数据库密码
    $dbname = "sso";  // 使用数据库名
    $networkname = "ens160"
?>